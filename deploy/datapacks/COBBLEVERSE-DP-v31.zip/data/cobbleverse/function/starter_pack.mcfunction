item replace entity @s armor.chest with sophisticatedbackpacks:iron_backpack
item replace entity @s weapon.offhand with cobblemon:pokedex_red
give @s cobblemon:poke_ball 10
give @s cobblemon:oran_berry 10
item replace entity @s hotbar.8 with rctmod:trainer_card
gamerule healersHealPC true
recipe give @s *
execute as @a run item modify entity @s armor.chest {function: 'minecraft:set_components', components: {"sophisticatedcore:accent_color": -12827478, "sophisticatedcore:main_color": -5231066}}